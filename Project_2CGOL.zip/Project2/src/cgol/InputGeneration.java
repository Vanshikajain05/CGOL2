package cgol;

/*****
*@author: Vanshika Jain
*The program is based on cgol using multithreading.
 */
 
import java.util.Scanner;

public class InputGeneration {
	public static void main(String[] args) 
    { 
		int i,j,M,N; String gen;
		System.out.println("Enter number of rows and columns:");
		
		Scanner sc=new Scanner(System.in); //scan rows and columns
		
         M=sc.nextInt();
         N=sc.nextInt();
        
        System.out.println("rows:"+M+"  "+"columns:"+N);
        
                                                   // initializing the grid. 
                         int grid[][]=new int[M][N]; 
                   
                       System.out.println("Enter elements of array containing whole number 1 and 0 only: \\n"); 
                       
        for(i=0; i<M;i++) //for loop for scanning and printing the input generation
        {
            for(j=0;j<N;j++)
              {
              	 
                  	grid[i][j]=sc.nextInt();
                    }
          }
            for (i=0; i<M; i++) 
                   { 
                      for (j=0; j<N; j++) 
                             { 
                     if (grid[i][j] == 0) 
                         System.out.print("0");  // printing the next life
                else
                     System.out.print("1"); 
                        } 
            System.out.println(); 
        } 
                       System.out.println(); 
        
     do{
    	
    	 Multithreading obj=new Multithreading(M,N,grid);   //printing next life if you want otherwise game ends
                   obj.start();
                   gen=sc.next();
                  
     }        while(gen.equals("Next"));   
     
     System.out.println("Game ends");
     
    } 
  
                                      
}