package cgol;
/***
 * 
 * @author Vanshika Jain
 *
 */

public class Multithreading extends Thread {
     int M,N;
      int grid[][];
   int[][] gen = new int[50][50]; 
    
     public Multithreading(int M, int N, int grid[][]) {
    	 this.M=M;
    	 this.N=N;
    	 this.grid=grid;
     }
     
     public void run() {
   
    	 long time=System.nanoTime();   //execution time for next generation
  // Loop through every cell 
               for (int l=1; l<M-1; l++) 
                    { 
                for (int m=1; m<N-1; m++) 
                    { 
     // finding no Of Neighbors that are alive 
        int liveNeighbors = 0; 
     for (int i=-1; i<=1; i++) 
     
        for (int j=-1; j<=1; j++) 
             
           liveNeighbors += grid[l + i][m + j]; 

        // The cell needs to be subtracted from 
              // its neighbors as it was counted before 
                 liveNeighbors -= grid[l][m]; 

               // Implementing the Rules of Life 

                  // Cell is lonely and dies 
                  if ((grid[l][m]==1) && (liveNeighbors<2)) 
                 {
                  gen[l][m]=0; 
                        }
                     // Cell dies due to over population 
                  else if ((grid[l][m]==1) && (liveNeighbors>3)) {
                       gen[l][m] = 0; 
                             }
                      // A new cell is born 
                 else if ((grid[l][m]==0) && (liveNeighbors==3)) {
                           gen[l][m]=1; 
                                 }
                       // Remains the same 
                            else 
                                 {
                             gen[l][m]=grid[l][m]; 
                                 }
                                  } 
                               } 
                    
                
                      System.out.println("Next Generation"); 
                   for (int i=0; i<M; i++) 
                       { 
                          for (int j=0; j<N; j++) 
                           { 
                          
                                System.out.print(gen[i][j]); 
                                    } 
                          System.out.println();
                             } 
                   
                   for (int i=0; i<M; i++) 
                   { 
                      for (int j=0; j<N; j++)        //converting next life as input generation
                       { 
                    	  grid[i][j]=gen[i][j];
                       }
                       }
                   
                   long period=System.nanoTime()-time;
                   System.out.println("Execution time: " + period + " ns");
                   System.out.println("Enter 'Next' for printing next generation:");
     }
}
